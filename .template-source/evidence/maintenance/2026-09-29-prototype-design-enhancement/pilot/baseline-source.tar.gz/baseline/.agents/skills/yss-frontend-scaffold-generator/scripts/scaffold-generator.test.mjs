#!/usr/bin/env node
import assert from "node:assert/strict";
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, readlinkSync, rmSync, statSync, symlinkSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";

const root = mkdtempSync(path.join(os.tmpdir(), "yss-frontend-scaffold-"));
process.on("exit", () => rmSync(root, { recursive: true, force: true }));
const template = path.join(root, "template"), output = path.join(root, "output"), evidence = path.join(root, "evidence"), bin = path.join(root, "bin");
mkdirSync(template); mkdirSync(bin);
writeFileSync(path.join(template, "package.json"), JSON.stringify({ name: "__APP_NAME__", scripts: { lint: "noop", "type-check": "noop", build: "noop" } }));
writeFileSync(path.join(template, "pnpm-lock.yaml"), "lockfileVersion: '9.0'\n");
writeFileSync(path.join(template, "micro-config.json"), JSON.stringify({ name: "__MICROAPP_NAME__", route: "__BASE_ROUTE__" }));
mkdirSync(path.join(template, "assets"));
writeFileSync(path.join(template, "assets/binary.bin"), Buffer.from([0, 255, 95, 95, 65, 80, 80, 95, 78, 65, 77, 69, 95, 95]));
writeFileSync(path.join(template, "assets/large.txt"), "__APP_NAME__".repeat(200_000));
writeFileSync(path.join(template, "assets/run.sh"), "#!/bin/sh\necho __APP_NAME__\n");
chmodSync(path.join(template, "assets/run.sh"), 0o755);
symlinkSync("run.sh", path.join(template, "assets/current"));
for (const args of [["init"], ["config", "user.email", "test@example.com"], ["config", "user.name", "test"], ["remote", "add", "origin", template], ["add", "."], ["commit", "-m", "fixture"]]) {
  const result = spawnSync("git", args, { cwd: template, encoding: "utf8" }); assert.equal(result.status, 0, result.stderr);
}
const commit = spawnSync("git", ["rev-parse", "HEAD"], { cwd: template, encoding: "utf8" }).stdout.trim();
mkdirSync(path.join(template, "node_modules"));
writeFileSync(path.join(template, "node_modules/cache.txt"), "not approved");
writeFileSync(path.join(template, "micro-config.json"), "uncommitted edit");
const contract = {
  schema_version: 4, kind: "project-scaffold-contract", contract_id: "frontend.demo.v1", contract_version: "1", status: "approved", persisted_ref: "docs/.scratch/demo/scaffold-contract.json", current_version: true,
  delivery_role: "frontend", scaffold_kind: "frontend-yss-vue3", generator_skill: "yss-frontend-scaffold-generator", implementation_repository: output, target_output_dir: output, repository_scope: "external-repository", init_git: false,
  frontend: { app_name: "demo-app", microapp_name: "demo", base_route: "/demo", package_manager: "pnpm", template: { repository: template, commit }, openapi_impact: "not-applicable", openapi_not_applicable_reason: "static-only" },
  allowed_write_paths: [output], expected_evidence_files: [".yss/scaffold-generation.json"], verification_commands: ["pnpm install --frozen-lockfile", "pnpm lint", "pnpm type-check", "pnpm build"], approval: { approval_ref: "decision://frontend", approver: "user" }, generation_policy: { mode: "initialize-only", existing_target: "unsupported", old_project_migration: "unsupported", template_upgrade: "unsupported" }
};
const contractFile = path.join(root, "contract.json"); writeFileSync(contractFile, JSON.stringify(contract));
const mockPnpm = path.join(bin, "pnpm"); writeFileSync(mockPnpm, "#!/bin/sh\nexit 0\n"); chmodSync(mockPnpm, 0o755);
const runner = path.resolve(".agents/skills/yss-frontend-scaffold-generator/scripts/generate_and_verify_scaffold.mjs");
const result = spawnSync(process.execPath, [runner, "--contract-file", contractFile, "--template-checkout", template, "--output-dir", output, "--evidence-dir", evidence], { encoding: "utf8", env: { ...process.env, PATH: `${bin}:${process.env.PATH}` } });
assert.equal(result.status, 0, result.stderr);
assert.equal(existsSync(path.join(output, ".git")), false);
assert.equal(JSON.parse(readFileSync(path.join(output, "package.json"))).name, "demo-app");
assert.equal(JSON.parse(readFileSync(path.join(output, ".yss", "scaffold-generation.json"))).completion_level, "empty-scaffold-verified");
assert.equal(JSON.parse(readFileSync(path.join(evidence, "scaffold-verification.json"))).commands.length, 4);
assert.equal(existsSync(path.join(output, "node_modules")), false);
assert.equal(JSON.parse(readFileSync(path.join(output, "micro-config.json"))).name, "demo");
assert.deepEqual(readFileSync(path.join(output, "assets/binary.bin")), readFileSync(path.join(template, "assets/binary.bin")));
assert.deepEqual(readFileSync(path.join(output, "assets/large.txt")), readFileSync(path.join(template, "assets/large.txt")));
assert.equal(readlinkSync(path.join(output, "assets/current")), "run.sh");
assert.equal(statSync(path.join(output, "assets/run.sh")).mode & 0o777, 0o755);
assert.match(readFileSync(path.join(output, "assets/current"), "utf8"), /echo demo-app/);
const generated = JSON.parse(readFileSync(path.join(output, ".yss/scaffold-generation.json"))).generated_files;
assert.deepEqual(generated, ["assets/binary.bin", "assets/current", "assets/large.txt", "assets/run.sh", "micro-config.json", "package.json", "pnpm-lock.yaml"]);
const second = spawnSync(process.execPath, [runner, "--contract-file", contractFile, "--template-checkout", template, "--output-dir", output, "--evidence-dir", evidence], { encoding: "utf8", env: { ...process.env, PATH: `${bin}:${process.env.PATH}` } });
assert.notEqual(second.status, 0);
assert.match(second.stderr, /must not exist or must be empty/);
process.stdout.write("前端脚手架受控生成场景验证通过\n");

// Bundled source proves portability without the source project's checkout or credentials.
const { generate } = await import('./generate_scaffold.mjs');
const { createHash } = await import('node:crypto');
const bundleManifest = readFileSync(path.resolve('.agents/skills/yss-frontend-scaffold-generator/references/data-quality-v1.manifest.json'));
const bundle = structuredClone(contract);
bundle.frontend.template = { kind: 'bundled', baseline_id: 'data-quality-v1', manifest_digest: `sha256:${createHash('sha256').update(bundleManifest).digest('hex')}` };
bundle.verification_commands = ['pnpm install --frozen-lockfile', 'pnpm lint:check', 'pnpm type-check', 'pnpm build', 'pnpm build:standalone'];
bundle.target_output_dir = path.join(root, 'bundled'); bundle.implementation_repository = bundle.target_output_dir; bundle.allowed_write_paths = [bundle.target_output_dir];
const saveBundle = () => writeFileSync(contractFile, JSON.stringify(bundle));
saveBundle();
const bundled = generate({ contractFile, outputDir: bundle.target_output_dir });
assert.equal(bundled.template.checkout, undefined);
const bundledPackage = JSON.parse(readFileSync(path.join(bundle.target_output_dir, 'package.json')));
assert.equal(bundledPackage.packageManager, 'pnpm@12.4.2');
assert.equal(bundledPackage.engines.node, '>=22.12.0');
assert.equal(bundledPackage.engines.pnpm, '>=12.4.2 <13');
assert.match(readFileSync(path.join(bundle.target_output_dir, 'README.md'), 'utf8'), /pnpm 12\.4\.2/);
assert.equal(JSON.parse(readFileSync(path.join(bundle.target_output_dir, 'packages/package.json'))).dependencies['ant-design-vue'], '4.2.6');
assert.equal(JSON.parse(readFileSync(path.join(bundle.target_output_dir, 'packages/src/config/theme.json'))).algorithm, 'default');
for (const forbidden of ['.npmrc', 'node_modules', '.git', 'packages/src/views/datasource/index.vue', 'scripts/sync-openapi.js']) assert.equal(existsSync(path.join(bundle.target_output_dir, forbidden)), false, forbidden);
assert.throws(() => generate({ contractFile, outputDir: bundle.target_output_dir }), /must not exist or must be empty/);
bundle.target_output_dir = path.join(root, 'rejected'); bundle.implementation_repository = bundle.target_output_dir; bundle.allowed_write_paths = [bundle.target_output_dir];
const goodDigest = bundle.frontend.template.manifest_digest;
bundle.frontend.template.manifest_digest = `sha256:${'0'.repeat(64)}`; saveBundle();
assert.throws(() => generate({ contractFile, outputDir: bundle.target_output_dir }), /manifest digest/);
assert.equal(existsSync(bundle.target_output_dir), false);
bundle.frontend.template.manifest_digest = goodDigest;
bundle.frontend.app_name = 'invalid";execute()'; saveBundle();
assert.throws(() => generate({ contractFile, outputDir: bundle.target_output_dir }), /kebab-case/);
bundle.frontend.app_name = 'safe'; bundle.frontend.base_route = '/../escape'; saveBundle();
assert.throws(() => generate({ contractFile, outputDir: bundle.target_output_dir }), /base_route/);
bundle.frontend.base_route = '/safe'; bundle.frontend.openapi_impact = 'frozen'; bundle.frontend.openapi_json_ref = path.join(root, 'openapi.json'); bundle.frontend.openapi_json_digest = `sha256:${'0'.repeat(64)}`;
writeFileSync(bundle.frontend.openapi_json_ref, '{"openapi":"3.1.0"}'); saveBundle();
assert.throws(() => generate({ contractFile, outputDir: bundle.target_output_dir }), /OpenAPI JSON digest mismatch/);
assert.equal(existsSync(bundle.target_output_dir), false);
process.stdout.write('Data Quality bundled baseline / source binding / no-write rejection scenarios passed\n');
