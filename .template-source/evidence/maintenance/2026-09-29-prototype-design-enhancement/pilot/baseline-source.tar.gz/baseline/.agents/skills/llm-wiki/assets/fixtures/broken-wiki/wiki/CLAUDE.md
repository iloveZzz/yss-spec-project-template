# CLAUDE.md

fixture schema
