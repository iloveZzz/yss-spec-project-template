# 离线候选比较工具

已有本地 HTML 候选需要公平比较时使用。该工具只生成评审辅助快照，不是 H1/H2 原型生成器、批准工具或生产构建器。低保真探索无需伪造 H1/H2 批准；正式原型仍按阶段合同构建和验证。

## 作者输入

候选分别使用独立目录；每个目录资源自包含，包含当前项目 `tokens.css` 与字节相同的共同 `scenarios.js`。页面在首次加载时消费 `#scenario=<scenario>`，恢复固定数据；未知场景显示错误。仅声明支持场景不足以证明页面实际正确，浏览器必须检查真实状态、失败输入保留及重置。

输入 JSON 使用项目根相对路径，例如：

```json
{
  "schema_version": 1,
  "comparison_id": "task-options",
  "title": "资料处理方案",
  "comparison_ref": "docs/.scratch/demo/design/demo-interaction-spec.md",
  "scenario_ref": "docs/.scratch/demo/design/candidates/shared-scenarios.js",
  "cases": [
    { "id": "normal", "label": "正常处理", "scenario": "primary" },
    { "id": "retry", "label": "失败恢复", "scenario": "failure" }
  ],
  "variants": [
    { "id": "a", "label": "逐项处理", "root": "docs/.scratch/demo/design/candidates/a", "entry": "index.html", "cases": ["normal", "retry"] },
    { "id": "b", "label": "批量处理", "root": "docs/.scratch/demo/design/candidates/b", "entry": "index.html", "cases": ["normal", "retry"] },
    { "id": "c", "label": "队列引导", "root": "docs/.scratch/demo/design/candidates/c", "entry": "index.html", "cases": ["normal", "retry"] }
  ]
}
```

示例名称不构成需求；只有 Spec 允许这些行为时才使用。工具支持 2–3 个候选，条件探索按阶段合同使用三个。比较问题、差异轴、保真度、事前标准及用户选择仍写在 `comparison_ref` 的交互说明中；`case.id` 只是该比较中的入口标识，`scenario` 引用已有场景，不替代 Visual Baseline 的 `case_id`。

```bash
node .agents/skills/yss-prototype-stage/scripts/prototype-comparison.mjs prepare \
  --project-root <项目根> --feature demo \
  --input docs/.scratch/demo/design/comparison-input.json
```

输出固定为 `docs/.scratch/demo/design/comparisons/task-options/`。非空目录拒绝覆盖；新比较用新的 comparison_id。工具复制候选、比较记录、场景、设计与 Token 来源，并在副本入口插入本地 readiness 脚本，不修改作者源或正式原型。接收者无需 Node；复制整个目录后直接打开 `index.html`。

## 评审与复验

外层选择候选、共同场景或重置；每次替换 frame，使内存状态从头开始。`#variant=a&case=retry` 可复现选择。预览不缩放，使用当前可用宽度；准确 `1440×900` 或 `390×844` 产品截图应通过“原尺寸单独打开”进入候选页面并设置目标视口，不截取评审工具作为正式产品基线。

未知候选、场景和无法加载的入口显示错误。readiness 消息只说明页面加载，不能证明业务行为。页面内部的临时交互不会反向修改外层所选初始场景；再次切换或重置回到该初始场景。

```bash
node .agents/skills/yss-prototype-stage/scripts/prototype-comparison.mjs validate --root <比较包>
node .agents/skills/yss-prototype-stage/scripts/prototype-comparison.mjs validate --root <比较包> --project-root <项目根>
node .agents/skills/yss-prototype-stage/scripts/prototype-comparison.mjs seal --root <比较包>
```

第一条核验便携快照，第二条还检查四项绑定来源是否漂移。修改未批准的比较副本后，审查变更再 seal；已用于用户决定的版本保持只读并新建版本。seal 不更新来源快照或证明批准，来源变化需重新 prepare。

验证检查摘要、共同数据/Token、候选入口、越界路径、符号链接及常见网络依赖。静态扫描不是完整 JavaScript 分析：仍须在独立目录断网执行，核对请求、console、键盘、焦点、窄屏，以及切换/重置后的实际数据。正式交付继续使用 Prototype Evidence v4、Visual Baseline v1 和现有用户决定记录。
