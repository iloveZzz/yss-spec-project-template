from pathlib import Path
import json,random,datetime
p=Path('/tmp/yss-fast-optimization-20261001/formal');d=json.loads((p/'benchmark.json').read_text());done=sum(r.get('valid') is True for r in d['samples']);out={'time':datetime.datetime.now().isoformat(timespec='seconds'),'status':d['status'],'valid_runs':done,'total_runs':d['pairs_per_state']*6,'summary':d['summary']}
rng=random.Random(d['seed']);order=[]
for state in ['first-run','repeat','input-change']:
 for pair in range(d['pairs_per_state']):
  modes=['legacy','optimized'];rng.shuffle(modes);order.extend(f'{state}-{pair:02d}-{mode}' for mode in modes)
if d['status']=='running' and done<len(order):
 name=order[done];out['current']=name;f=p/name/'tooling/metrics.json'
 if f.exists():
  m=json.loads(f.read_text());out.update(tooling_status=m['status'],prepared_steps=len(m['preparations']),files_completed=len(m['executions']),files_total=len(m.get('selected_files',[])))
  records=[]
  for ref in f.parent.glob('*.tests.jsonl'):
   for line in ref.read_text().splitlines():
    try:row=json.loads(line)
    except json.JSONDecodeError:continue
    if row.get('event') in ['test:pass','test:fail']:records.append(row)
  out['test_results']=len(records)
if d.get('error'):out['error']=d['error']
print(json.dumps(out,ensure_ascii=False))
