import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
const root = process.argv[2];
const result = process.argv[3];
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tooling-scheduling-'));
try {
  const files = ['plugin-project.test.mjs', 'new-default-serial.test.mjs'].map(name => {
    const file = path.join(temp, name);
    fs.writeFileSync(file, `import test from 'node:test';import assert from 'node:assert/strict';test(${JSON.stringify(name)},async()=>{assert.equal(process.env.YSS_TOOLING_PLUGIN_FIXTURE,undefined);await new Promise(r=>setTimeout(r,100));});`);
    return file;
  });
  const env = {...process.env, YSS_TOOLING_MODE: 'optimized', YSS_TOOLING_CONCURRENCY: '2', YSS_TOOLING_REPORT_DIR: result};
  delete env.NODE_TEST_CONTEXT;
  const r = spawnSync(process.execPath, [path.join(root, '.template-source/tooling/node/scripts/test-with-plugin-clis.mjs'), ...files], {cwd:root,env,encoding:'utf8',timeout:120000,maxBuffer:4*1024*1024});
  assert.equal(r.status,0,r.stderr);
  const m = JSON.parse(fs.readFileSync(path.join(result,'metrics.json')));
  assert.equal(m.selected_files.length,2);assert.equal(m.executions.length,2);assert.equal(m.copies.length,0);
  assert.equal(m.preparations.filter(x=>x.name.includes('backend-plugin-build')).length,0);
  assert.equal(m.tests.filter(x=>x.event==='test:pass').length,2);
  const rows=m.executions.sort((a,b)=>Date.parse(a.started_at)-Date.parse(b.started_at));
  assert.ok(rows.every(x=>x.name.includes('serial-')));
  assert.ok(Date.parse(rows[1].started_at)>=Date.parse(rows[0].started_at)+rows[0].duration_ms-2);
  assert.equal(m.input_drift,false);console.log('PASS: unknown files, including a known basename at another path, execute once in serial without fixture reuse');
} finally {fs.rmSync(temp,{recursive:true,force:true});}
