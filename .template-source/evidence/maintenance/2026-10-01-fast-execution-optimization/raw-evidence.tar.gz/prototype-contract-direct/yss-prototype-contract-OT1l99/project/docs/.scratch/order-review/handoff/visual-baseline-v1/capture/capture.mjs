// deterministic capture
