import pathlib,subprocess,json,shutil,hashlib
P=pathlib.Path(__file__).parent;R=pathlib.Path.cwd();S=P/'source'
def run(args,**kw):return subprocess.run(args,check=True,**kw)
run(['git','clone','--quiet','--shared',str(R),str(S)])
links=subprocess.check_output(['git','ls-files','--stage'],cwd=R,text=True).splitlines()
for line in links:
 if not line.startswith('160000 '):continue
 sha=line.split()[1];ref=line.split('\t')[1]
 if not (R/ref/'.git').exists():continue
 run(['git','clone','--quiet','--shared',str(R/ref),str(S/ref)])
 run(['git','checkout','--quiet','--detach',sha],cwd=S/ref)
 run(['git','config',f'submodule.{ref}.url',str(R/ref)],cwd=S)
refs=set(subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines())
refs.update(['scripts/fixtures/contract-efficiency/schema-rejection.test.mjs','.template-source/tooling/node/scripts/tooling-fixture.mjs','.template-source/tooling/node/scripts/tooling-process.mjs','.template-source/tooling/node/scripts/tooling-reporter.mjs','.template-source/tooling/node/test/tooling-execution.test.mjs'])
for ref in sorted(refs):
 target=S/ref;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/ref,target)
(P/'candidate-inputs.json').write_text(json.dumps({ref:hashlib.sha256((R/ref).read_bytes()).hexdigest() for ref in sorted(refs)},indent=2))
run(['pnpm','install','--frozen-lockfile'],cwd=S/'.template-source/tooling/node')
print(S)
