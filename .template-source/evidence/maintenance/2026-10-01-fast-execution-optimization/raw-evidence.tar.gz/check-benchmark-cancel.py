from pathlib import Path
import tempfile,subprocess,sys,time,os,signal,json,shutil
harness=Path(sys.argv[1]);base=Path(tempfile.mkdtemp(prefix='benchmark-cancel-'));root=base/'root';output=base/'report';root.mkdir();subject=root/'.template-source/plugins/yss-backend-delivery/README.md';subject.parent.mkdir(parents=True);subject.write_bytes(b'original\n');entry=root/'scripts/verify-template-fast';entry.parent.mkdir();marker=base/'child.pid';entry.write_text('#!'+sys.executable+'\nimport os,time,pathlib\npathlib.Path('+repr(str(marker))+').write_text(str(os.getpid()))\ntime.sleep(300)\n');entry.chmod(0o755)
child_pid=None;process=None
try:
 for args in [['git','init','--quiet',str(root)],['git','-C',str(root),'add','.'],['git','-C',str(root),'-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','--quiet','-m','fixture']]:subprocess.run(args,check=True)
 with (base/'stdout').open('wb') as out,(base/'stderr').open('wb') as err:
  process=subprocess.Popen([sys.executable,str(harness),'--root',str(root),'--output',str(output),'--pairs','3'],stdout=out,stderr=err)
  deadline=time.monotonic()+10
  while not marker.exists():
   assert process.poll() is None,'benchmark ended before child started'
   assert time.monotonic()<deadline,'child did not start'
   time.sleep(.03)
  child_pid=int(marker.read_text());subject.write_bytes(b'changed-before-cancel\n');process.send_signal(signal.SIGTERM);code=process.wait(timeout=15)
 assert code!=0
 assert subject.read_bytes()==b'original\n','SIGTERM must restore replay input'
 assert not list(base.glob('tooling-benchmark-*.lock')),'SIGTERM must release own lock'
 report=json.loads((output/'benchmark.json').read_text());assert report['status']=='failed' and report['source_restored'] is True
 try:os.kill(child_pid,0)
 except ProcessLookupError:pass
 else:raise AssertionError('benchmark child still alive')
 print('PASS: SIGTERM reclaims child, restores replay input, releases lock and records non-success')
finally:
 if process and process.poll() is None:process.kill();process.wait()
 if child_pid:
  try:os.kill(child_pid,signal.SIGKILL)
  except ProcessLookupError:pass
 shutil.rmtree(base)
