import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import assert from 'node:assert/strict';import {execFileSync} from 'node:child_process';import {pathToFileURL} from 'node:url';
import {verificationInputDigest} from '/Users/zhudaoming/Projects/yss-spec-project-template/scripts/lib/verification-report.mjs';
const helper=await import(pathToFileURL(process.argv[2]));
const d=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'permission-probe-')));
try {
 const source=path.join(d,'source'),artifact=path.join(d,'artifact'),manifestFile=path.join(d,'manifest.json');fs.mkdirSync(source);fs.mkdirSync(artifact);fs.writeFileSync(path.join(source,'input'),'fixed');fs.writeFileSync(path.join(artifact,'run'),'payload',{mode:0o755});
 execFileSync('git',['init','--quiet',source]);execFileSync('git',['-C',source,'add','.']);execFileSync('git',['-C',source,'-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','--quiet','-m','fixture']);
 const digest=helper.publishTestFixture({sourceRoot:source,artifact,manifestFile,inputDigest:verificationInputDigest(source),dependencies:[]});fs.chmodSync(path.join(artifact,'run'),0o4755);
 assert.throws(()=>helper.materializeTestPlugin({sourceRoot:source,output:path.join(d,'copy'),build:()=>assert.fail('must not rebuild'),environment:{YSS_TOOLING_PLUGIN_FIXTURE:manifestFile,YSS_TOOLING_PLUGIN_FIXTURE_SHA256:digest}}),/artifact changed/);
 console.log('PASS: special permission-bit change rejected');
}finally{fs.rmSync(d,{recursive:true,force:true});}
