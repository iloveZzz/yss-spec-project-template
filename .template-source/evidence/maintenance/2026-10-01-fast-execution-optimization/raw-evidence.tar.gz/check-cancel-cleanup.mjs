import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import assert from 'node:assert/strict';import {spawn} from 'node:child_process';import {once} from 'node:events';
const [root,result]=process.argv.slice(2),temp=fs.mkdtempSync(path.join(os.tmpdir(),'tooling-cancel-probe-')),marker=path.join(temp,'marker.json'),testFile=path.join(temp,'cancel.test.mjs');
let observed,child;
try {
 fs.writeFileSync(testFile,`import test from 'node:test';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';test('cancel during test',async()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'cancelled-consumer-'));fs.writeFileSync(${JSON.stringify(marker)},JSON.stringify({dir,pid:process.pid}));await new Promise(()=>{setInterval(()=>{},1000)});});`);
 const env={...process.env,YSS_TOOLING_MODE:'optimized',YSS_TOOLING_REPORT_DIR:result};delete env.NODE_TEST_CONTEXT;
 child=spawn(process.execPath,[path.join(root,'.template-source/tooling/node/scripts/test-with-plugin-clis.mjs'),testFile],{cwd:root,env,stdio:['ignore','ignore','inherit']});
 const closed=once(child,'close');const deadline=Date.now()+120000;
 while(!fs.existsSync(marker)){assert.ok(Date.now()<deadline,'test did not start');assert.equal(child.exitCode,null);await new Promise(r=>setTimeout(r,30));}
 observed=JSON.parse(fs.readFileSync(marker));child.kill('SIGTERM');const timer=setTimeout(()=>child.kill('SIGKILL'),10000);const [code]=await closed;clearTimeout(timer);assert.notEqual(code,0);
 const m=JSON.parse(fs.readFileSync(path.join(result,'metrics.json')));assert.equal(m.status,'failed');assert.equal(m.cleanup.code,0);
 assert.throws(()=>process.kill(observed.pid,0),/ESRCH/);
 assert.equal(fs.existsSync(observed.dir),false,'cancelled test temporary directory must be reclaimed');
 console.log('PASS: cancellation retains failure report, kills test process and reclaims its owned temporary directory');
}finally{if(child?.exitCode===null)child.kill('SIGTERM');if(observed&&fs.existsSync(observed.dir))fs.rmSync(observed.dir,{recursive:true,force:true});fs.rmSync(temp,{recursive:true,force:true});}
