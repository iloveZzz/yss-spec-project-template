import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {verifyShadcnSources} from '../scripts/build-shadcn-prototype.mjs';
import {resourceErrors} from '../scripts/offline-html.mjs';
test('vendored shadcn components bind a fixed upstream revision and exact source bytes',async()=>{
 const registry=await verifyShadcnSources();
 assert.equal(registry.components.length,11);
 for(const item of registry.components)assert(item.url.includes(`/blob/${registry.revision}/`));
 const pkg=JSON.parse(await readFile(new URL('../assets/shadcn-authoring/package.json',import.meta.url)));
 assert(!pkg.dependencies.antd);assert(pkg.dependencies.react);
 for(const version of Object.values({...pkg.dependencies,...pkg.devDependencies}))assert.match(version,/^\d+\.\d+\.\d+$/);
});
test('authored TypeScript receives the same offline network checks as JavaScript',()=>{
 assert(resourceErrors('entry.tsx','fetch("https://example.test")',{}).length);
 assert(resourceErrors('entry.ts','import("./remote.js")',{}).length);
});
