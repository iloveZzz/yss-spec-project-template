from pathlib import Path
import subprocess,tempfile,json,time
root=Path('/Users/zhudaoming/Projects/yss-spec-project-template');out=Path(Path('/tmp/yss-business-continuation-dir').read_text()).resolve();results=[]
def run(label,args,cwd=root):
 start=time.monotonic();p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/(label+'.log')).write_text(p.stdout);r=dict(label=label,args=args,cwd=str(cwd),exit_code=p.returncode,seconds=round(time.monotonic()-start,2));results.append(r);(out/'build-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(label,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
run('root-sync',['node','scripts/sync-strategic-handoff-tools'])
for side in ['design','backend','frontend']:
 profile=root/f'submodules/yss-harness-{side}-agent'
 for script in ['generate-lifecycle-artifacts','sync-skills','update-skill-lock','verify-lifecycle-registry','verify-harness-profile']:
  run(side+'-'+script,['node','scripts/'+script],profile)
for side,folder in [('design','create-yss-strategic-design'),('backend','create-yss-harness-backend'),('frontend','create-yss-harness-frontend')]:
 cli=root/'submodules'/folder
 run(side+'-core',['node','scripts/sync-core.mjs',str(root),'WORKTREE'],cli)
 run(side+'-template',['node','scripts/sync-template.mjs',str(root/f'submodules/yss-harness-{side}-agent'),'WORKTREE'],cli)
 run(side+'-bundle',['node','scripts/verify-bundle.mjs'],cli)
run('spec-template',['node','scripts/sync-template.js'],root/'submodules/create-yss-spec')
print('EVIDENCE='+str(out),flush=True)
