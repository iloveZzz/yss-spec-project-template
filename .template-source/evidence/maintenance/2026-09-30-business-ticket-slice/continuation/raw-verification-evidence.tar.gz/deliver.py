from pathlib import Path
import subprocess,json,time,hashlib,os,shutil,sys
root=Path('/Users/zhudaoming/Projects/yss-spec-project-template');out=Path(Path('/tmp/yss-business-continuation-dir').read_text()).resolve();packs=out/'packs';packs.mkdir(exist_ok=True);results=[]
def run(label,args,cwd=root,expected=0):
 start=time.monotonic();p=subprocess.run([str(x) for x in args],cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);(out/(label+'.log')).write_text(p.stdout+p.stderr);results.append(dict(label=label,args=[str(x) for x in args],cwd=str(cwd),exit_code=p.returncode,expected=expected,seconds=round(time.monotonic()-start,2)));(out/'integration-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(label,p.returncode,flush=True)
 if p.returncode!=expected:print((p.stdout+p.stderr)[-2200:],flush=True);raise SystemExit(1)
 return p.stdout
profiles=[('spec','create-yss-spec','create-yss-spec'),('design','create-yss-strategic-design','create-yss-harness-design'),('backend','create-yss-harness-backend','create-yss-harness-backend'),('frontend','create-yss-harness-frontend','create-yss-harness-frontend')]
if len(sys.argv)>1:profiles=profiles[[x[0] for x in profiles].index(sys.argv[1]):]
if (out/'integration-results.json').exists():results=json.loads((out/'integration-results.json').read_text())
for side,folder,binname in profiles:
 cli=root/'submodules'/folder
 packed=json.loads(run(side+'-pack',['npm','pack','--ignore-scripts','--json','--pack-destination',packs],cli));info=packed[0] if isinstance(packed,list) else next(iter(packed.values()));tarball=packs/info['filename'];prefix=out/('install-'+side)
 run(side+'-install',['npm','install','--prefix',prefix,'--ignore-scripts','--no-audit','--no-fund',tarball])
 entry=prefix/'node_modules/.bin'/binname;target=out/('instance-'+side)
 if target.exists():shutil.rmtree(target)
 run(side+'-init',[entry,*(['--agent-runtime','codex'] if side=='spec' else []),'--project-name','Business Ticket Fixture','--business-domain','模板合成验收','--team-size','3','--target-dir',target])
 tracker=target/'.template-spec/agents/issue-tracker.md';assert 'business_ticket_version: 1' in tracker.read_text()
 if side=='spec':
  for stage in ['stage.spec-architecture','stage.product-design','stage.system-data-engineering']:
   run('spec-assets-'+stage,[entry,'assets','ensure',stage,'--apply','--target-dir',target])
  run('spec-assets-repeat',[entry,'assets','ensure','stage.spec-architecture','--apply','--target-dir',target])
 for file in ['scripts/verify-business-tickets','scripts/lib/business-tickets.mjs','.template-spec/process/schemas/business-tickets-v1.schema.json','.template-spec/templates/business-ticket-template.md']:
  assert (target/file).is_file(),(side,file)
 note=target/'docs/user-note.md';note.parent.mkdir(exist_ok=True);note.write_text('用户原有文件，必须保留。\n');tracker.write_text(tracker.read_text()+'\n用户追踪配置注记。\n');before=tracker.read_bytes()
 run(side+'-sync',[entry,'sync','--apply','--target-dir',target]);assert tracker.read_bytes()==before and note.read_text()=='用户原有文件，必须保留。\n'
 metadata=target/('.yss-template.json' if side=='spec' else f'.yss-harness-{side}.json');first=metadata.read_bytes()
 run(side+'-sync-repeat',[entry,'sync','--apply','--target-dir',target]);assert metadata.read_bytes()==first,'重复同步非幂等'
 tracker.write_text(tracker.read_text().replace('  business_ticket_version: 1\n',''));legacy=tracker.read_bytes();run(side+'-legacy-sync',[entry,'sync','--apply','--target-dir',target]);assert tracker.read_bytes()==legacy,'旧配置被自动启用'
 run(side+'-legacy-diagnostic',['node','--input-type=module','-e',f"import {{businessTicketVersion}} from {json.dumps((target/'scripts/lib/business-tickets.mjs').as_uri())}; if(businessTicketVersion({json.dumps(str(target))})!==null)process.exit(1); console.log('legacy-unassessed; automatic migration not performed');"])
 template=target/'.template-spec/templates/business-ticket-template.md';template.write_text(template.read_text()+'\n用户模板定制。\n');custom=template.read_bytes();run(side+'-conflict-visible',[entry,'sync','--apply','--target-dir',target],expected=0);assert template.read_bytes()==custom
 # Execute the packaged validator against real synthetic source files.
 fixtureModule=target/'scripts/fixtures/strategic-handoff/fixture.mjs';fixtureModule=fixtureModule if fixtureModule.exists() else root/'scripts/fixtures/strategic-handoff/fixture.mjs'
 code=f"import {{fixture}} from {json.dumps(fixtureModule.as_uri())}; await fixture({json.dumps(str(target))},{{handoffVersion:5,businessTickets:true}});"
 if fixtureModule.exists():
  fixtureScript=out/(side+'-fixture.mjs');fixtureScript.write_text(code);run(side+'-fixture',['node',fixtureScript])
  run(side+'-business-formal',['node',target/'scripts/verify-business-tickets','source/tickets.yaml','--root',target,'--mode','formal','--json'])
print('all package integration scenarios passed',flush=True)
