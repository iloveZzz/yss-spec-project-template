# YSS Skill Execution Result

核心 YSS skill 必须消费已批准合同版本，并返回：

后端结果顶层带与当前 resolution 完全一致的 `architecture_identity`；每条验证记录还须有整数 `exit_code`。身份缺失、Profile 未 supported、验证非零或没有执行时间均不得 accepted。

```yaml
execution_result:
  schema_version: 2
  skill:
  slice_id:
  work_unit_id:
  status: implemented
  consumed_contract:
    contract_ref:
    contract_id:
    contract_version:
    registry_digest:
    compiler_contract_digest:
    component_bindings_digest: # 合同含 component_bindings 时必填
    quality_baseline_ref:
    context_plan_ref:
  changed_files:
    - path:
      contract_area: common | frontend | backend | contract | cross_repo
  evidence_files:
    - path:
      evidence_type: code | test | generated | review | verification
      behavior_ref:
  verification_results:
    - command:
      result:
      executed_at:
  constraint_results:
    - constraint_id: # 后端审查时为 canonical 稳定 ID
      applicability_basis: [] # 后端覆盖工具派生依据
      constraint:
      status: passed | failed | not-applicable
      evidence_ref:
  doubt_driven_review:
    status: not-applicable | completed | blocked
    record_ref:
  seam_deferred:
    - risk:
      owner:
      follow_up_ticket:
      verification_plan:
      target_version_or_release_date:
  deviations:
    - rule:
      reason:
      approval_ref:
  new_impacts:
    - impact_type:
      evidence_ref:
  not_applicable_reason:
```

允许状态：`implemented`、`seam-deferred`、`drift`、`violation`、`not-applicable`。

实现合同编译器必须验证：

1. `consumed_contract.contract_version` 与当前批准版本一致，Registry、编译器以及适用的 `component_bindings_digest` 与批准合同一致且保持 current。
2. `changed_files` 全部位于工作单元和切片允许路径内。
3. `expected_evidence_files` 全部存在并能回指行为。
4. 验证命令包含实际结果和时间；计划命令不算证据。
5. `seam_deferred` 有风险、责任人、补齐 Ticket、验证计划和目标版本 / 发布日期。
6. `new_impacts` 非空时暂停并重路由。
7. `drift` 触发 Architecture Re-check；`violation` 阻断 build。
8. `status: not-applicable` 必须填写 `not_applicable_reason`；其他状态保留字段但可为空。

专项 skill 自报 `implemented` 不等于最终通过，生命周期编排器和独立 Reviewer 必须复核。

`verification_results` 不得为空，每项必须包含非空 `command`、`result` 和 `executed_at`。路径校验按完整目录边界判断，`apps/backend/project1-escape` 不属于 `apps/backend/project1/`；Harness 内路径还必须通过项目路径策略。完整重路由时旧合同必须标记 `stale`，新合同版本递增并保留旧合同引用、失效原因和触发器。

后端独立审查在既有 constraint_results 中消费稳定规则 ID、规则/代码/证据摘要与完整适用性集合；输入增加 scope_kind 与 standards_coverage_ref/digest。见 yss-backend-spec-review/references/standards-coverage.md。实现者结果不代替独立 code-review；历史未携带新字段的报告只读兼容。
