import './list-detail-standard'
